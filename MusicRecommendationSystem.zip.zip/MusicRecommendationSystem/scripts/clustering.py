import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Load the preprocessed dataset
df = pd.read_csv('preprocessed_songs.csv')

# Define the features
features = ['danceability', 'energy', 'loudness', 'speechiness', 'acousticness', 
            'instrumentalness', 'liveness', 'valence', 'tempo', 'duration_ms']

# Clustering using KMeans
kmeans = KMeans(n_clusters=2, random_state=0)  # Adjusted to 2 clusters
df['cluster'] = kmeans.fit_predict(df[features])

# Save the dataframe with clusters
df.to_csv('clustered_songs.csv', index=False)

# Visualize clusters
plt.scatter(df['danceability'], df['energy'], c=df['cluster'], cmap='viridis')
plt.title('Clusters of Songs')
plt.xlabel('Danceability')
plt.ylabel('Energy')
plt.show()
